export default function NotFound() {
  return <div>Eror 404 Not Found!</div>;
}
