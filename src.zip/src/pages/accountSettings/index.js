export default function AccountSettingsPage() {
  return <h1>Settings</h1>;
}
