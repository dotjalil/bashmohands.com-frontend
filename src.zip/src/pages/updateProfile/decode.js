// import jwt from 'jsonwebtoken';

// function decodeMyToken(token) {
//   try {
//     // Verify and decode the JWT token using your secret key
//     const secret = process.env.TOKEN_SECRET; // Replace with your actual secret key
//     const decodedToken = jwt.verify(token, secret);

//     return decodedToken;
//   } catch (error) {
//     // Handle token verification or decoding errors here
//     console.error('Error decoding JWT token:', error);
//     return null; // Return null in case of an error
//   }
// }

// export default decodeJWT;